card_input = input("Digite o número do cartão: ")

def verefCard(cardNumber):
    alternador = 1
    cardInvert = cardNumber[::-1]
    preSoma = []
    for i in range(len(cardInvert)):
        if alternador % 2 == 0:
            if (int(cardInvert[i]) * 2) <= 9:
                preSoma.append(int(cardInvert[i]) * 2)
            else:
                preSoma.append(int(cardInvert[i]) * 2 - 9)
        else:
            preSoma.append(int(cardInvert[i]))
        alternador += 1

    soma = sum(preSoma)
    if soma % 10 == 0:
        return True
    else:
        return False

def flagCard(cardNumber):
    card_size = len(cardNumber)

    # Visa
    if cardNumber[0] == "4" and (card_size == 13 or card_size == 16 or card_size == 19):
        return "Visa"
    
    # MasterCard
    elif card_size == 16 and (51 <= int(cardNumber[:2]) <= 55 or 2221 <= int(cardNumber[:4]) <= 2720):
        return "MasterCard"

            
    # American Express
    elif (cardNumber[:2] == "34" or cardNumber[:2] == "37") and card_size == 15:
        return "American Express"
    
    # Discover
    elif (card_size == 16 or card_size == 19) and (cardNumber[:4] == "6011" or cardNumber[:2] == "65" or cardNumber[:3] == "644" or cardNumber[:3] == "645" or cardNumber[:3] == "646" or cardNumber[:3] == "647" or cardNumber[:3] == "648" or cardNumber[:3] == "649"):
        return "Discover"

    # Diners Club
    elif card_size == 14 and (cardNumber[:3] == "300" or cardNumber[:3] == "301" or cardNumber[:3] == "302" or cardNumber[:3] == "303" or cardNumber[:3] == "304" or cardNumber[:3] == "305" or cardNumber[:2] == "36" or cardNumber[:2] == "38"):
        return "Diners Club"
    
    else:
        return "Bandeira não encontrada ou inexistente"


if not card_input.isnumeric(): 
    raise ValueError("Digite apenas números!") 

else:
    if len(card_input) < 13:
        raise ValueError("O número do cartão deve ter mais de 12 digitos!")
    
    if len(card_input) > 19:
        raise ValueError("O número do cartão deve ter menos de 20 digitos!")

print("o cartão é válido: ", verefCard(card_input),"\nA bandeira dele é:", flagCard(card_input))